/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_spi.h"
#include "stm32f4xx_tim.h"
#include "math.h"

#define SPIx                       SPI1 //SPI number
#define GPIOx                      GPIOA //GPIO port of SPI pins

#define TIMEOUT         ((uint32_t)0x1000)


int main(void);
void init(void);
void delay(u32 ms);
static uint8_t spiSend(uint8_t byte);

void initSpi(void);


#endif /* __MAIN_H */
