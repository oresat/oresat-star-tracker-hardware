/**
  ******************************************************************************
  * @file    main.c
  * @author  Ac6
  * @version V1.0
  * @date    01-December-2013
  * @brief   Default main function.
  ******************************************************************************
*/


#include "stm32f4xx.h"
#include "stm32f4_discovery.h"
#include "main.h"

__IO uint32_t  timeout = TIMEOUT;

int main(void)
{
	initSpi();

	while(1)
	{

		GPIO_SetBits(GPIOE, GPIO_Pin_3);
		//delayns(100000);
		spiSend(0xAA);
		GPIO_ResetBits(GPIOE, GPIO_Pin_3);
//		for(uint8_t i = 0 ; i < 0xff ; i++)
//		{
//
//		//uint8_t result = spiSend(i);
		//delayns(100);
//		}
	}

}

static uint8_t spiSend(uint8_t byte)
{
  /* Loop while DR register in not emplty */
//  timeout = TIMEOUT;
//  //uint8_t status = SPI_I2S_GetFlagStatus(SPIX, SPI_I2S_FLAG_TXE);
//  //while (status == RESET)
//  while (SPI_I2S_GetFlagStatus(SPIX, SPI_I2S_FLAG_TXE) == RESET)
//  {
//      uint8_t temp = 0xff;
//	  if((timeout--) == 0) return temp;
//  }

  /* Send a Byte through the SPI peripheral */
  SPI_I2S_SendData(SPIx, byte);
  //SPI_I2S_SendData(SPIX, byte+1);

//below is recieve section
//  /* Wait to receive a Byte */
//  timeout = TIMEOUT;
//  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_RXNE) == RESET)
//  {
//    if((timeout--) == 0)
//    {
//    	while(1){} //if timeout, loop forever. In the future this can return an error?
//    }
//  }
//
//  /* Return the Byte read from the SPI bus */
//  return (uint8_t)SPI_I2S_ReceiveData(SPIx);
}

void initSpi(void) {
	//must change these manually for now
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); //chip select, this can be changed

    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    //GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_Init(GPIOx, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOx, GPIO_PinSource5, GPIO_AF_SPI1);
    GPIO_PinAFConfig(GPIOx, GPIO_PinSource6, GPIO_AF_SPI1);
    GPIO_PinAFConfig(GPIOx, GPIO_PinSource7, GPIO_AF_SPI1);

    //must change these manually for now
//    GPIO_PinAFConfig(GPIOx, GPIO_PinSource13, GPIO_AF_SPI2);
//	GPIO_PinAFConfig(GPIOx, GPIO_PinSource14, GPIO_AF_SPI2);
//	GPIO_PinAFConfig(GPIOx, GPIO_PinSource15, GPIO_AF_SPI2);

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;
    GPIO_Init(GPIOE, &GPIO_InitStruct);
    GPIO_SetBits(GPIOE, GPIO_Pin_3);

    SPI_InitTypeDef SPI_InitStructure;
    SPI_I2S_DeInit(SPIx);
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_Init(SPIx, &SPI_InitStructure);

    SPI_Cmd(SPIx, ENABLE);
}

void delayns(u32 ms) {
    //ms *= 1000;
    while (--ms > 0) {
        __NOP();
    }
}
