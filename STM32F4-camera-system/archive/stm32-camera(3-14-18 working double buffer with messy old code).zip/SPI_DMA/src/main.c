/**
  ******************************************************************************
  * @file    SPI/SPI_TwoBoards/SPI_DataExchangeDMA/main.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    18-January-2013
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

__IO uint32_t  timeout = TIMEOUT;

/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup SPI_DataExchangeDMA
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
    uint8_t aTxBuffer[4] = {0xCC, 0xAA, 0x8, 0x1};
    //uint8_t aTxBuffer = 0xFF;
__IO uint8_t aRxBuffer [BUFFERSIZE];
__IO uint8_t ubRxIndex = 0;
__IO uint8_t ubTxIndex = 0;
__IO uint32_t TimeOut = 0;
volatile temp = 0;

//SPI_InitTypeDef  SPI_InitStructure; this is now done in SPIinit

/* Private function prototypes -----------------------------------------------*/
static void SPI_Config(void);
static void SysTickConfig(void);
static TestStatus Buffercmp(uint8_t* pBuffer1, __IO uint8_t* pBuffer2, uint16_t BufferLength);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       files (startup_stm32f40xx.s/startup_stm32f427x.s) before to branch to 
       application main. 
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f4xx.c file
     */ 
  
  /* SPI configuration */
  SPI_Config();
  
  //IRq Config
  //irqInit();

  /* SysTick configuration */
  SysTickConfig();
  //SPI_Cmd(SPIx, ENABLE); //this is now done in SPIinit
//  while(1)
//  {
//SPI_Cmd(SPIx, ENABLE);
//  GPIOE->BSRRH = GPIO_Pin_3;
//
//  spiSend(0xAA);
//  GPIOE->BSRRL = GPIO_Pin_3;
//  }

#ifdef SPI_MASTER

  /* Master board configuration */    
  /* Initializes the SPI communication */
  //SPI_InitStructure.SPI_Mode = SPI_Mode_Master; //these are now done in SPIinit
  //SPI_Init(SPIx, &SPI_InitStructure);
  
  /* The Data transfer is performed in the SPI using Direct Memory Access */
  //while (1)
  //{

//  /* Enable DMA SPI TX Stream */
  //DMA_Cmd(SPIx_TX_DMA_STREAM,ENABLE);
//
//  /* Enable DMA SPI RX Stream */
//  DMA_Cmd(SPIx_RX_DMA_STREAM,ENABLE);
//
//  /* Enable SPI DMA TX Requsts */
  //SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Tx, ENABLE);
//
//  /* Enable SPI DMA RX Requsts */
//  SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Rx, ENABLE);
  
  

  while (1)
  {
	//GPIO_ResetBits(GPIOE, GPIO_Pin_3);

  /* Enable DMA SPI TX Stream */
	DMA_Cmd(SPIx_TX_DMA_STREAM,ENABLE);

	/* Enable SPI DMA TX Requsts */
	SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Tx, ENABLE);

	/* Enable SPI DMA RX Requsts */
	//SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Rx, ENABLE);
	aTxBuffer[0] = 0xAA;
	aTxBuffer[1] = 0xCC;
	aTxBuffer[2] = 0xFF;
	aTxBuffer[3] = 0x00;
//	aTxBuffer[0] = 0xF2;
//	aTxBuffer[1] = 0x00;
//	aTxBuffer[2] = 0x00;
//	aTxBuffer[3] = 0x12;


  /* Enable the SPI peripheral */
	//GPIO_ResetBits(GPIOE, GPIO_Pin_3);
	//GPIO_SetBits(GPIOE, GPIO_Pin_3);

	GPIOE->BSRRH = GPIO_Pin_3;
	SPI_Cmd(SPIx, ENABLE); //this is now done in SPIinit

	while (DMA_GetFlagStatus(SPIx_TX_DMA_STREAM,SPIx_TX_DMA_FLAG_TCIF)==RESET);
	//GPIO_SetBits(GPIOE, GPIO_Pin_3);
	GPIOE->BSRRL = GPIO_Pin_3;
	DMA_ClearFlag(SPIx_TX_DMA_STREAM,SPIx_TX_DMA_FLAG_TCIF); //not sure if this is needed since the interrupt clears the flag


	//the below must happen for chip select to work properly?
	DMA_Cmd(SPIx_TX_DMA_STREAM,DISABLE);
	SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Tx, DISABLE);
	SPI_Cmd(SPIx, DISABLE);
	//delay(1);

   }
  


#endif /* SPI_MASTER */

//#ifdef SPI_SLAVE
//  /* Slave board configuration */
//  /* Initializes the SPI communication */
//  //SPI_InitStructure.SPI_Mode = SPI_Mode_Slave; //these are now done in SPIinit
//  //SPI_Init(SPIx, &SPI_InitStructure);
//
//  /* Enable DMA SPI TX Stream */
//  DMA_Cmd(SPIx_TX_DMA_STREAM,ENABLE);
//
//  /* Enable DMA SPI RX Stream */
//  DMA_Cmd(SPIx_RX_DMA_STREAM,ENABLE);
//
//  /* Enable SPI DMA TX Requests */
//  SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Tx, ENABLE);
//
//  /* Enable SPI DMA RX Requests */
//  SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Rx, ENABLE);
//
//  /* Enable the SPI peripheral */
//  SPI_Cmd(SPIx, ENABLE);
//
//#endif /* SPI_SLAVE */

  /* Waiting the end of Data transfer */
  while (DMA_GetFlagStatus(SPIx_TX_DMA_STREAM,SPIx_TX_DMA_FLAG_TCIF)==RESET);
  while (DMA_GetFlagStatus(SPIx_RX_DMA_STREAM,SPIx_RX_DMA_FLAG_TCIF)==RESET);
  
  /* Clear DMA Transfer Complete Flags */
  DMA_ClearFlag(SPIx_TX_DMA_STREAM,SPIx_TX_DMA_FLAG_TCIF);
  DMA_ClearFlag(SPIx_RX_DMA_STREAM,SPIx_RX_DMA_FLAG_TCIF);  
  
  /* Disable DMA SPI TX Stream */
  DMA_Cmd(SPIx_TX_DMA_STREAM,DISABLE);

  /* Disable DMA SPI RX Stream */
  DMA_Cmd(SPIx_RX_DMA_STREAM,DISABLE);  
  
  /* Disable SPI DMA TX Requsts */
  SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Tx, DISABLE);

  /* Disable SPI DMA RX Requsts */
  SPI_I2S_DMACmd(SPIx, SPI_I2S_DMAReq_Rx, DISABLE);

  /* Disable the SPI peripheral */
  SPI_Cmd(SPIx, DISABLE);


}



static uint8_t spiSend(uint8_t byte)
{
  /* Loop while DR register in not emplty */
//  timeout = TIMEOUT;
//  //uint8_t status = SPI_I2S_GetFlagStatus(SPIX, SPI_I2S_FLAG_TXE);
//  //while (status == RESET)
//  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_TXE) == RESET)
//  {
//      uint8_t temp = 0xff;
//	  if((timeout--) == 0) return temp;
//  }

  /* Send a Byte through the SPI peripheral */
  SPI_I2S_SendData(SPIx, byte);
  //SPI_I2S_SendData(SPIX, byte+1);

//below is recieve section
//  /* Wait to receive a Byte */
//  timeout = TIMEOUT;
//  while (SPI_I2S_GetFlagStatus(SPIx, SPI_I2S_FLAG_RXNE) == RESET)
//  {
//    if((timeout--) == 0)
//    {
//    	while(1){} //if timeout, loop forever. In the future this can return an error?
//    }
//  }
//
//  /* Return the Byte read from the SPI bus */
//  return (uint8_t)SPI_I2S_ReceiveData(SPIx);
}

/**
  * @brief  Configures the SPI Peripheral.
  * @param  None
  * @retval None
  */
static void SPI_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  DMA_InitTypeDef DMA_InitStructure;

  /* Peripheral Clock Enable -------------------------------------------------*/
  /* Enable the SPI clock */
 //RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
  
  /* Enable GPIO clocks */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
  
  /* Enable DMA clock */
  RCC_AHB1PeriphClockCmd(SPIx_DMA_CLK, ENABLE);

  /* SPI GPIO Configuration --------------------------------------------------*/
  /* GPIO Deinitialisation */ //This just disables whatever port is passed? was not in simple SPI example
  GPIO_DeInit(GPIOx);
  
  /* Connect SPI pins to AF5 */  
  //must change these manually for now
//    GPIO_PinAFConfig(GPIOx, GPIO_PinSource13, GPIO_AF_SPI2);
//  	GPIO_PinAFConfig(GPIOx, GPIO_PinSource14, GPIO_AF_SPI2);
//  	GPIO_PinAFConfig(GPIOx, GPIO_PinSource15, GPIO_AF_SPI2);
  GPIO_PinAFConfig(GPIOx, GPIO_PinSource5, GPIO_AF_SPI1);
  GPIO_PinAFConfig(GPIOx, GPIO_PinSource6, GPIO_AF_SPI1);
  GPIO_PinAFConfig(GPIOx, GPIO_PinSource7, GPIO_AF_SPI1);


  GPIO_StructInit(&GPIO_InitStructure); //not sure if this is needed? Was not in original DMA example
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
  GPIO_Init(GPIOx, &GPIO_InitStructure);


  //chip select setup
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
  GPIO_ResetBits(GPIOE, GPIO_Pin_3);

  SPI_InitTypeDef SPI_InitStructure;
  SPI_I2S_DeInit(SPIx);
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_Init(SPIx, &SPI_InitStructure);

  
  /* DMA configuration -------------------------------------------------------*/
  /* Deinitialize DMA Streams */
  DMA_DeInit(SPIx_TX_DMA_STREAM);
  DMA_DeInit(SPIx_RX_DMA_STREAM);

  /* Configure DMA Initialization Structure */
  DMA_InitStructure.DMA_BufferSize = BUFFERSIZE ;
  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable ;
  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull ;
  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single ;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_PeripheralBaseAddr =(uint32_t) (&(SPIx->DR)) ;
  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  /* Configure TX DMA */
  DMA_InitStructure.DMA_Channel = SPIx_TX_DMA_CHANNEL ;
  DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral ;
  DMA_InitStructure.DMA_Memory0BaseAddr =(uint32_t)aTxBuffer ;
  DMA_Init(SPIx_TX_DMA_STREAM, &DMA_InitStructure);
  /* Configure RX DMA */
  DMA_InitStructure.DMA_Channel = SPIx_RX_DMA_CHANNEL ;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory ;
  DMA_InitStructure.DMA_Memory0BaseAddr =(uint32_t)aRxBuffer ;

  DMA_Init(SPIx_RX_DMA_STREAM, &DMA_InitStructure);

  NVIC_InitTypeDef NVIC_InitStructure;

  	//Enable DMA channel IRQ Channel TX */

  NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream4_IRQn;
  //NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream5_IRQn;

  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;

  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;

  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

  NVIC_Init(&NVIC_InitStructure);

  //DMA_ITConfig(DMA1_Stream4, DMA_IT_TC, ENABLE); // Enable DMA1 Channel Transfer Complete interrupt

}

void irqInit()
{
	NVIC_InitTypeDef NVIC_InitStructure;

	//Enable DMA1 channel IRQ Channel */

	NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream4_IRQn;

	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;

	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;

	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

	NVIC_Init(&NVIC_InitStructure);

}

void DMA1_Stream4_IRQHandler(void)
{
//	if(temp == 0)
//	{
//	//GPIO_ResetBits(GPIOE, GPIO_Pin_3);
//	GPIOE->BSRRH = GPIO_Pin_3;
//	temp = 1;
//	}else{
	//GPIO_SetBits(GPIOE, GPIO_Pin_3);
	GPIOE->BSRRL = GPIO_Pin_3;
//	temp = 0;
//	}
//	//DMA_ClearITPendingBit(DMA1_IT_GL1);
	DMA_ClearITPendingBit(DMA1_Stream4, DMA_IT_TCIF4);
}

void DMA2_Stream5_IRQHandler(void)
{
//	if(temp == 0)
//	{
//	//GPIO_ResetBits(GPIOE, GPIO_Pin_3);
//	GPIOE->BSRRH = GPIO_Pin_3;
//	temp = 1;
//	}else{
	//GPIO_SetBits(GPIOE, GPIO_Pin_3);
	GPIOE->BSRRL = GPIO_Pin_3;
//	temp = 0;
//	}
//	//DMA_ClearITPendingBit(DMA1_IT_GL1);
	DMA_ClearITPendingBit(DMA2_Stream5, DMA_IT_TCIF5);
}

void delay(u32 ms) {
    ms *= 1000;
    while (--ms > 0) {
        __NOP();
    }
}


/**
  * @brief  Configure a SysTick Base time to 10 ms.
  * @param  None
  * @retval None
  */
static void SysTickConfig(void)
{
  /* Setup SysTick Timer for 10ms interrupts  */
  if (SysTick_Config(SystemCoreClock / 100))
  {
    /* Capture error */
    while (1);
  }

  /* Configure the SysTick handler priority */
  NVIC_SetPriority(SysTick_IRQn, 0x0);
}


/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval PASSED: pBuffer1 identical to pBuffer2
  *         FAILED: pBuffer1 differs from pBuffer2
  */
static TestStatus Buffercmp(uint8_t* pBuffer1, __IO uint8_t* pBuffer2, uint16_t BufferLength)
{
  while (BufferLength--)
  {
    if (*pBuffer1 != *pBuffer2)
    {
      return FAILED;
    }
    pBuffer1++;
    pBuffer2++;
  }

  return PASSED;
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}


#endif

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
